<?php
#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       : impressum.php                                             ##
## --------------------------------------------------------------------------- ##
##  Refactored by  : Shadow                                                    ##
## --------------------------------------------------------------------------- ##
##  Project        : Novaterra                                                  ##
#################################################################################

use App\Utils\AccessLogger;

include_once("GameEngine/config.php");
include_once("GameEngine/Database.php");
require_once __DIR__ . "/GameEngine/Lang/loader.php";
tz_load_language(LANG);

AccessLogger::logRequest();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" <?php echo tz_html_dir_attrs(); ?>>

<head>
    <title><?php echo SERVER_NAME; ?> - Impressum</title>

    <link rel="stylesheet" type="text/css" href="img/tutorial/main.css"/>
    <link rel="stylesheet" type="text/css" href="img/tutorial/flaggs.css"/>

    <meta name="content-language" content="en"/>
    <meta http-equiv="imagetoolbar" content="no"/>

    <script src="mt-core.js" type="text/javascript"></script>
    <script src="new.js" type="text/javascript"></script>

    <!-- 🔥 INLINE CSS FIX (footer + layout safe) -->
    <style type="text/css">

        body {
            margin: 0;
            padding: 0;
        }

        .wrapper {
            min-height: 100vh;
        }

        .grit {
            overflow: hidden; /* FIX FLOAT BUG */
        }

        /* 🔥 FOOTER 100% VIZIBIL */
        .footer {
            clear: both;
            width: 100%;
            height: 60px;
            margin-top: 30px;

            display: block;

            background: #0f0f0f;
            border-top: 2px solid #333;

            text-align: center;
            color: #bbb;
            font-size: 12px;
            line-height: 60px;
            font-family: Arial, Helvetica, sans-serif;
        }

        .footer:before {
            content: "Novaterra by Shadow © 2010-" attr(data-year);
        }

        /* optional polish */
        a {
            color: #d4b87a;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body class="webkit contentPage">

<div class="wrapper">

    <div id="country_select"></div>

    <div id="header">
        <h1><?php echo PUBLIC_WELCOME_TO; ?> <?php echo SERVER_NAME; ?></h1>
    </div>

    <div id="navigation">

        <a href="index.php" class="home">
            <img src="img/x.gif" alt="Novaterra"/>
        </a>

        <table class="menu">
            <tr>
                <td><a href="tutorial.php"><span><?php echo TUTORIAL; ?></span></a></td>
                <td><a href="anleitung.php"><span><?php echo PUBLIC_MANUAL; ?></span></a></td>
                <td><a href="https://github.com/omotaz556-cloud/tatar/discussions" target="_blank"><span><?php echo FORUM; ?></span></a></td>
                <td><a href="index.php?signup"><span><?php echo PUBLIC_REGISTER; ?></span></a></td>
                <td><a href="index.php?login"><span><?php echo LOGIN; ?></span></a></td>
            </tr>
        </table>

    </div>

    <div id="content">

        <div class="grit">

            <h1>Impressum</h1>

            <p class="submenu">

                <b>Project:</b><br/>
                Novaterra by Shadow<br/><br/>

                <b>Initiator & Lead Developer:</b><br/>
                Shadow (Catalin Novgorodschi)<br/><br/>

                <b><?php echo PUBLIC_ABOUT_PROJECT; ?></b><br/>
                Open-source Novaterra 3.6 engine modernization project focused on performance,
                stability and gameplay preservation.<br/><br/>

                <b><?php echo PUBLIC_MAIN_GOALS; ?></b><br/>
                - Preserve classic Novaterra gameplay<br/>
                - Refactor legacy codebase<br/>
                - Improve performance and stability<br/>
                <?php echo PUBLIC_ADD_TRIBES; ?><br/>
                - Maintain community-driven development<br/><br/>

                <b>Source Code:</b><br/>
                <a href="https://github.com/omotaz556-cloud/tatar" target="_blank">
                    https://github.com/omotaz556-cloud/tatar
                </a><br/><br/>

                <b>Disclaimer:</b><br/>
                <?php echo PUBLIC_UNOFFICIAL_PROJECT; ?><br/><br/>

                © 2010-<?php echo date('Y'); ?> Novaterra Project

            </p>

            <!-- 🔥 FOOTER FIXED -->
            <div class="footer" data-year="<?php echo date('Y'); ?>"></div>

        </div>

    </div>

</div>

<!-- overlay -->
<div id="iframe_layer" class="overlay">

    <div class="mask closer"></div>

    <div class="overlay_content">

        <a href="index.php" class="closer">
            <img class="dynamic_img" alt="<?php echo PUBLIC_CLOSE; ?>" src="img/un/x.gif" />
        </a>

        <h2>Anleitung</h2>

        <div id="frame_box"></div>

        <div class="footer" data-year="<?php echo date('Y'); ?>"></div>

    </div>

</div>

</body>
</html>
